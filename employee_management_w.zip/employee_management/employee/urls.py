from django.urls import path

from . import views

urlpatterns = [
    path("employee/", views.employee, name="employee"),
    path("position/", views.position, name="position"),
    path("project/", views.project, name="project"),
    path("project/<int:project_id>/detail/", views.project_detail, name="detail"),
    path("project/<int:project_id>/delete/", views.delete, name="delete"),
]