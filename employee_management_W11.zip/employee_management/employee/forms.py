from django import forms
from .models import *
from django.forms import ModelForm, SplitDateTimeField
from django.forms.widgets import Textarea, TextInput, SplitDateTimeWidget
from django.core.exceptions import ValidationError

from datetime import date, datetime

class employeeform(ModelForm):
    location = forms.CharField(widget=forms.TextInput(attrs={"cols": 30, "rows": 3}))
    district = forms.CharField(max_length=100)
    province = forms.CharField(max_length=100)
    postal_code = forms.CharField(max_length=15)

    class Meta:
        model = Employee
        fields = [
            "first_name", 
            "last_name", 
            "gender", 
            "birth_date", 
            "hire_date", 
            "salary", 
            "position_id",
            "location",
            "district",
            "province",
            "postal_code"
        ]
        widgets = {
            'birth_date': forms.widgets.DateInput(attrs={'type': 'date'}),
            'hire_date': forms.widgets.DateInput(attrs={'type': 'date'})
        }

    def clean_hire_date(self):
        hiredate = self.cleaned_data["hire_date"]
        if hiredate > date.today():
            raise ValidationError("hiredate > birthdate")
        return hiredate


class projectform(ModelForm):
    class Meta:
        model = Project
        fields = [
            "name",
            "description",
            "manager",
            "due_date",
            "start_date",
        ]

        widgets = {
            "start_date" : forms.DateInput(attrs={'type': 'date'}),
            "due_date" : forms.DateInput(attrs={'type': 'date'})
        }

    def clean_start_date(self):
        startdate = self.cleaned_data["start_date"]
        duedate = self.cleaned_data["due_date"]
        if startdate > duedate:
            raise ValidationError("startdate more than duedate na")
        return startdate

class editprojectform(ModelForm):
    class Meta:
        model = Project
        fields = [
            "name",
            "start_date",
            "due_date",
            "description",
            "manager",
            "staff",
        ]

        widgets = {
            "start_date" : forms.DateInput(attrs={'type': 'date'}),
            "due_date" : forms.DateInput(attrs={'type': 'date'})
        }

    def clean(self):
        cleaned_data = super().clean()
        startdate = cleaned_data["start_date"]
        duedate = cleaned_data["due_date"]
        if startdate > duedate:
            raise ValidationError("startdate more than duedate na")
        return cleaned_data




    # อันเก่า Week 9
    # first_name = forms.CharField(label="Firstname", max_length=100)
    # last_name = forms.CharField(label="Lastname", max_length=100)

    # gender_choices = {
    #     (1, 'Male'),
    #     (2, 'Female'),
    #     (3, 'Other')
    # }

    # gender = forms.ChoiceField(
    #     choices = gender_choices
    # )

    # birth_date = forms.DateField(label="Birt hdate", widget=forms.DateInput(attrs={'type': 'date'}))
    # hire_date = forms.DateField(label="Hire date", widget=forms.DateInput(attrs={'type': 'date'}))
    # salary = forms.DecimalField(label="Salary", max_digits=10, decimal_places=2)

    # position = forms.ModelChoiceField(
    #     queryset=Position.objects.all()
    # )