from django import forms
from .models import *

class employeeform(forms.Form):
    first_name = forms.CharField(label="Firstname", max_length=100)
    last_name = forms.CharField(label="Lastname", max_length=100)

    gender_choices = {
        (1, 'Male'),
        (2, 'Female'),
        (3, 'Other')
    }

    gender = forms.ChoiceField(
        choices = gender_choices
    )

    birth_date = forms.DateField(label="Birt hdate", widget=forms.DateInput(attrs={'type': 'date'}))
    hire_date = forms.DateField(label="Hire date", widget=forms.DateInput(attrs={'type': 'date'}))
    salary = forms.DecimalField(label="Salary", max_digits=10, decimal_places=2)

    position = forms.ModelChoiceField(
        queryset=Position.objects.all()
    )