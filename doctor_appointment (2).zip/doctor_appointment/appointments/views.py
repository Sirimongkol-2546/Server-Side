from django.shortcuts import render
from .models import *
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from appointments.serializers import *
from rest_framework.views import APIView
from rest_framework import status
from django.http import Http404
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from .permission import *


# Create your views here.
class MyTokenAuthentication(TokenAuthentication):
    keyword = "Bearer"

class DoctorList(APIView):
    authentication_classes = [MyTokenAuthentication]
    # ต้อง login ก่อนถึงจะสามารถใช้งานได้ อันนี้ถ้าไม่ส่ง token มาก้ใช้งานไม่ได้ ถ้าไม่กำหนด = เข้าใช้งานได้ทุกคน
    permission_classes = [IsAuthenticated]

    def get(self, request):
        doctors = Doctor.objects.all()
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)

class PatientList(APIView):
    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        patients = Patient.objects.all()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data)
    
class AppointmentList(APIView):
    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticatedOrReadOnly, UnknowAppointmentPermission]
    def get(self, request):
        appoinment = Appointment.objects.all()
        serializer = AppointmentSerializer(appoinment, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = createAppointmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
class AppointmentDetail(APIView):
    authentication_classes = [MyTokenAuthentication]
    permission_classes = [IsAuthenticated, AppointmentPermission]
    def get_object(self, pk):
        try:
            return Appointment.objects.get(pk=pk)
        except Appointment.DoesNotExist:
            raise Http404

    def get(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        serializer = AppointmentSerializer(appoinment)
        if serializer:
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def put(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        # data = request.data คือ ค่าที่ user ยิงไปเปลี่ยน
        serializer = editAppointmentSerializer(appoinment, data=request.data)

        self.check_object_permissions(request, appoinment)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def patch(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        serializer = editAppointmentSerializer(appoinment, data=request.data)

        self.check_object_permissions(request, appoinment)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    def delete(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)

        self.check_object_permissions(request, appoinment)

        appoinment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)