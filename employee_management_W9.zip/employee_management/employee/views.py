from django.shortcuts import render, redirect
from .models import *
from django.db.models import Count
from django.http import JsonResponse
from django.http import HttpResponseRedirect, HttpResponse

from .forms import *

# Create your views here.

def employee(request):
    employee_count = Employee.objects.count()
    employee_all = Employee.objects.all().order_by('-hire_date')
    context = {
        "all" : employee_all, 
        "count": employee_count,
        }
    return render(request, "employee.html", context)

def position(request):
    position_list = Position.objects.all().values('name', 'id').annotate(Count = Count('employee__id')).order_by("id")
    context = {
        "post" : position_list
    }
    return render(request, "position.html", context)

def project(request):
    project_all = Project.objects.all()
    context = {
        "pj_all" : project_all
    }

    return render(request, "project.html", context)

def delete(request,project_id):
    delete_q = Project.objects.get(pk=project_id)
    print(delete_q)
    delete_q.delete()
    return JsonResponse({'foo':'bar'}, status=200)

def project_detail(request, project_id):
    project_detail = Project.objects.get(pk=project_id)
    start = project_detail.start_date.strftime('%Y-%m-%d')
    end = project_detail.due_date.strftime('%Y-%m-%d')
    context = {
        "pj_detail" : project_detail,
        "start_project" : start,
        "end_project" : end
        }

    return render(request, "project_detail.html", context)


def project_detaill_add(request, project_id, employee_id):
    if(request.method == "PUT"):
        employee = Employee.objects.get(pk=employee_id)
        project_id = Project.objects.get(pk=project_id)
        project_id.staff.add(employee)
        return JsonResponse({'addStaff':'add'}, status=200)
    
def project_detaill_delete(request, project_id, employee_id):
    if(request.method == "DELETE"):
        employee = Employee.objects.get(pk=employee_id)
        project_id = Project.objects.get(pk=project_id)
        project_id.staff.remove(employee)
        return JsonResponse({'removeStaff':'remove'}, status=200)

# WEEK 09 FORM
def get_form(request):
    if request.method == "POST":
        form = employeeform(request.POST)

        if form.is_valid():
            print(form.cleaned_data)
            new_employee = Employee.objects.create(
                first_name = form.cleaned_data['first_name'],
                last_name = form.cleaned_data['last_name'],
                gender = form.cleaned_data['gender'],
                birth_date = form.cleaned_data['birth_date'],
                hire_date = form.cleaned_data['hire_date'],
                salary = form.cleaned_data['salary'],
                position = form.cleaned_data['position']
            )

            return redirect("employee")
        
    else:
        form = employeeform()

    return render(request, "employee_form.html", {"form": form})