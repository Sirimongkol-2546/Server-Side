from django.contrib import admin
from blogs.models import Blog
# Register your models here.

admin.site.register(Blog)
