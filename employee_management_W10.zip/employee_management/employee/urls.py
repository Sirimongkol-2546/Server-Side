from django.urls import path

from . import views

urlpatterns = [
    path("employee/", views.employee, name="employee"),
    path("position/", views.position, name="position"),
    path("project/", views.project, name="project"),
    path("project/<int:project_id>/detail/", views.edit_project_form, name="detail"),
    path("project/<int:project_id>/delete/", views.delete, name="delete"),
    path("project/<int:project_id>/detail/<int:employee_id>/add/", views.project_detaill_add, name="project_detail_add"),
    path("project/<int:project_id>/detail/<int:employee_id>/delete/", views.project_detaill_delete, name="project_detail_delete"),
    path("form/", views.get_form, name="form"),
    path("form/project/", views.project_form, name="project_form")
]