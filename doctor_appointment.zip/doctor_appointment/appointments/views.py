from django.shortcuts import render
from .models import *
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from appointments.serializers import *
from rest_framework.views import APIView
from rest_framework import status
from django.http import Http404


# Create your views here.

class DoctorList(APIView):
    def get(self, request):
        doctors = Doctor.objects.all()
        serializer = DoctorSerializer(doctors, many=True)
        return Response(serializer.data)

class PatientList(APIView):
    def get(self, request):
        patients = Patient.objects.all()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data)
    
class AppointmentList(APIView):
    def get(self, request):
        appoinment = Appointment.objects.all()
        serializer = AppointmentSerializer(appoinment, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = createAppointmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
class AppointmentDetail(APIView):
    def get_object(self, pk):
        try:
            return Appointment.objects.get(pk=pk)
        except Appointment.DoesNotExist:
            raise Http404

    def get(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        serializer = AppointmentSerializer(appoinment)
        if serializer:
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def put(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        serializer = editAppointmentSerializer(appoinment, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def patch(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        serializer = editAppointmentSerializer(appoinment, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)
    
    def delete(self, request, appnt_id):
        appoinment = self.get_object(appnt_id)
        appoinment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)